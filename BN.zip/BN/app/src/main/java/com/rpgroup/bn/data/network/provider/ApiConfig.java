package com.rpgroup.bn.data.network.provider;

public class ApiConfig {
  public static final String BASE_URL = "http://129.204.43.105:8080/";
}
