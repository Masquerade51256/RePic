package com.rpgroup.bn.model;

import java.util.List;

public class UserList {
  public List<User> mUsers;
}

