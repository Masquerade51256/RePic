package com.rpgroup.bn.view.views;

import android.content.Context;
import android.graphics.*;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

public class CircleImageView extends android.support.v7.widget.AppCompatImageView {
//  public CircleImageView(Context context, AttributeSet attrs) {
//    super(context, attrs);
//  }
//  public CircleImageView(Context context) {
//    super(context);
//  }
//  public CircleImageView(Context context, AttributeSet attrs, int defStyleAttr) {
//    super(context, attrs, defStyleAttr);
//  }
//  @Override
//  public void draw(Canvas canvas) {
//    super.draw(canvas);
//  }
//  @Override
//  protected void onDraw(Canvas canvas) {
//    Path clipPath = new Path();
//    int w = this.getWidth();
//    int h = this.getHeight();
//    clipPath.addRoundRect(new RectF(0, 0,w, h), 500.0f, 500.0f,Path.Direction.CW);
//    canvas.clipPath(clipPath);
//    super.onDraw(canvas);
//  }
private Paint mPaintBitmap = new Paint(Paint.ANTI_ALIAS_FLAG);
private Bitmap mRawBitmap;
private BitmapShader mShader;
private Matrix mMatrix = new Matrix();

public CircleImageView(Context context, AttributeSet attrs) {
  super(context, attrs);
    }

    @Override
   protected void onDraw(Canvas canvas) {
           Bitmap rawBitmap = getBitmap(getDrawable());
           if (rawBitmap != null){
                 int viewWidth = getWidth();
                   int viewHeight = getHeight();
                   int viewMinSize = Math.min(viewWidth, viewHeight);
                   float dstWidth = viewMinSize;
                   float dstHeight = viewMinSize;
                   if (mShader == null || !rawBitmap.equals(mRawBitmap)){
                         mRawBitmap = rawBitmap;
                         mShader = new BitmapShader(mRawBitmap, TileMode.CLAMP, TileMode.CLAMP);
                     }
                   if (mShader != null){
                         mMatrix.setScale(dstWidth / rawBitmap.getWidth(), dstHeight / rawBitmap.getHeight());
                         mShader.setLocalMatrix(mMatrix);
                     }
                   mPaintBitmap.setShader(mShader);
                   float radius = viewMinSize / 2.0f;
                   canvas.drawCircle(radius, radius, radius, mPaintBitmap);
               } else {
                   super.onDraw(canvas);
               }
        }

         private Bitmap getBitmap(Drawable drawable){
             if (drawable instanceof BitmapDrawable){
                   return ((BitmapDrawable)drawable).getBitmap();
               } else if (drawable instanceof ColorDrawable){
                   Rect rect = drawable.getBounds();
                   int width = rect.right - rect.left;
                   int height = rect.bottom - rect.top;
                   int color = ((ColorDrawable)drawable).getColor();
                   Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                   Canvas canvas = new Canvas(bitmap);
                   canvas.drawARGB(Color.alpha(color), Color.red(color), Color.green(color), Color.blue(color));
                   return bitmap;
               } else {
                   return null;
               }
         }
}
