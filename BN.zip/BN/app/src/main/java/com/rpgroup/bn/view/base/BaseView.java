package com.rpgroup.bn.view.base;

public interface BaseView {

}
