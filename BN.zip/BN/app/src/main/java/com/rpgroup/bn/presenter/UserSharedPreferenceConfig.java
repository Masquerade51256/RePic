package com.rpgroup.bn.presenter;

public class UserSharedPreferenceConfig {
  public static final String SP_USER_CONFIG = "user_config";
  public static final String SP_NAME = "sp_name";
  public static final String SP_MD5PASSWORD = "sp_md5Password";
}
